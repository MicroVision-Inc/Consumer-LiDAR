﻿--INFO--
This folder contains the USB drivers and .exe file for setting up as a UVC device
and also as a USB - Serial converter.

The Cypress CDC driver installation has two parts:
the Cypress USB adapter driver installation and the Cypress USB serial port
driver installation.

CYPRESS CDC DRIVER INSTALLER SETUP

The Cypress USB-Serial Software installer packages contain automatic Cypress CDC driver installation procedure build into this
installation package. Users just need follow installation wizard to complete the driver installation. This tool will also install
configuration utility, documentation and other essential tools required by USB-Serial product.
There is also a separate stand-alone windows driver installation package available for distribution. This package is called USB-
Serial Windows Driver Installer. This tool just installs cypress driver. End-user who distributes the cypress driver with their product
can use this stand-alone driver installer along with their product installer. This windows stand-alone driver installer works in silent
mode and in driver installation Wizard mode.

Location of the installer: Sentinel_SW_SDK_Python/Drivers/CypressDriverInstaller.exe

To use this driver installer in silent mode, please use the following command.
Silent Installation:
CypressDriverInstaller.exe /S /D=<PathToInstallDriverBinary>
‘/D’ is optional and the default driver installation path is (C:/Program Files/Cypress)
‘/S’ is the silent mode enabler switch

GUI based Installation:
Just run the executable CypressDriverInstaller.exe. GUI wizard will help the user to install the driver.


CYPRESS USB 3.0 DRIVER SETUP

The Cypress USB 3.0 driver can be installed for all USB-Serial vendor device interfaces. This is a generic vendor-class driver.

Follow the below steps to install the driver manually:
1. Connect the USB-Serial device to the machine.
2. Open Device Manager. To open Device Manager, click Start. In the search box, type Device Manager, and then, in the
list of results, click Device Manager.
3. Right-click on the USB-Serial device, and then, in the context menu, click Update Driver Software... to launch the Update
Driver Software dialog.
4. Click Browse my computer for driver software to select the driver INF file location.
5. In the Search for driver software in this location field, enter the location of the driver INF. The driver INF can be located
at <installpath>/drivers/<OS>/<ARCH>, where <OS> is the machine operating system and <ARCH>
is the operating system architecture.
 

Use CyUSB3.inf in the path shown in the table below for the respective OS.

		-------------------------------------                                                                                                                                                                                            
		Operating System	Folder path
		-------------------------------------
		Windows 10		Win10\x86
		Windows 10 x64		Win10\x64
		Windows 7		Win7\x86
		Windows 7 x64		Win7\x64


6.Click Next to start the vendor-class driver installation. After the installation completes, USB-Serial XXXX Vendor X node
appears under Universal Serial Bus controllers in the Device Manager.

7.Repeat steps 3 to 6 for all USB-Serial vendor-class device interfaces.


