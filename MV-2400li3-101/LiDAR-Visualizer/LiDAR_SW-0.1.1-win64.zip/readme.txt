--INFO--

This directory contains the following folders:
1)Apps 
2)Drivers

--Apps--
This folder has the MicroVision_LiDAR_Quad_Viewer folder which has the lidar_quadviewer python source code,the bin folder,the shortcut to the lidar_quadviewer.exe,the lidar_quadviewer user guide, a readme.txt and Microvision logo.

--Drivers--
This folder contains the USB drivers for Windows 7/10 for USB - Serial converter and .exe file for setting up as a UVC device.