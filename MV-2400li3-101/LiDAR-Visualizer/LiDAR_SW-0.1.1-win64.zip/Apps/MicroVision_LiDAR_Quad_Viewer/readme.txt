
--INFO--

This folder contains the following files/folders:
1)bin
2)lidar_quadviewer.exe - Shortcut
3)lidar_quadviewer.py
4)MicroVision LiDAR QuadViewer - User Guide.pdf
5)readme.txt

--bin--
This folder contains the lidar_quadviewer.exe executable of the lidar_quadviewer.py
and its dependent libraries.

--lidar_quadviewer.exe - Shortcut--
This is the shortcut to the lidar_quadviewer executable.
To launch the LiDAR QuadViewer, double click the shortcut icon.

--lidar_quadviewer.py--
This is the python source code of the Lidar_QuadViewer app.

--MicroVision LiDAR QuadViewer - User Guide.pdf--
Please refer this document for the detailed description on the LiDAR QuadViewer.

